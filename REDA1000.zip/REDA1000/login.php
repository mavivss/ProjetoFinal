<?php
session_start();
require_once("./assets/PHP/conexao.php");

if (!empty($_COOKIE['hash'])) {
    $sqlSelect = "SELECT * FROM usuario";
    $result = $banco->query($sqlSelect);
    while ($linhas = $result->fetch_assoc()) {
        $condicao = password_verify($linhas['id'], $_COOKIE['hash']) ? true : false;
        if ($condicao) {
            header('location: index.php');
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Reda1000</title>
    <script src="https://kit.fontawesome.com/fbcc70bc24.js" crossorigin="anonymous"></script>
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/IMG/FAVICON/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/IMG/FAVICON/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./assets/IMG/FAVICON/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/CSS/acesso.css">
</head>

<body>
    <header>
        <div class="logo">
            <p><img src="assets/IMG/FAVICON/apple-touch-icon.png" alt="logo"> Reda1000</p>
        </div>
        <div class="opcoes">
            <ul>
                <a class="criarconta" href="index.php">
                    <li>Home</li>
                </a>
                <a class="criarconta" href="cadastro.php">
                    <li>Criar Conta</li>
                </a>
                <a class="fazerlogin" href="login.php">
                    <li>Fazer Login</li>
                </a>
            </ul>
        </div>
        <nav class="menu-item">
            <ul>
                <a href="index.php">
                    <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Fazer Login</span></li>
                </a>
                <a href="cadastro.php">
                    <li><i class="fa fa-users" aria-hidden="true"></i><span>Fazer Cadastro</span></li>
                </a>
            </ul>
        </nav>
        <svg class="menu" width="35" height="35" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" color="#000">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
        </svg>
    </header>
    <div id="container">
        <div class="container">
            <form action="assets/PHP/login_validacao.php" method="POST">
                <fieldset>
                    <legend>Login</legend>
                </fieldset>
                <fieldset>
                    <input autocomplete="off" type="email" placeholder="E-mail" name="email">
                </fieldset>
                <fieldset>
                    <input autocomplete="off" id="password" type="password" placeholder="Senha" name="senha">
                    <i class="mostrarsenha fa fa-eye" aria-hidden="true"></i>
                </fieldset>
                <fieldset>
                    <button>Entrar</button>
                </fieldset>
                <fieldset>
                    <a href="cadastro.php">Não tem cadastro? Cadastre agora mesmo</a>
                </fieldset>
            </form>
        </div>
    </div>
    <?php
    if (!empty($_SESSION['alert'])) {
        echo "
        <div class='alert-session'>
            <p class='msg-alert-session'>{$_SESSION['alert']}</p>
        </div>
        ";
    }
    unset($_SESSION['alert']);
    ?>
    <script>
        document.querySelector('.menu').addEventListener('click', () => {
            document.querySelector('.menu-item').classList.toggle('menu-item-mostrar');
        });
        document.querySelector('#container').addEventListener('click', () => {
            document.querySelector('.menu-item').classList.remove('menu-item-mostrar');
        });

        var senha = document.getElementById('password');
        document.querySelector('.mostrarsenha').addEventListener('click', (e) => {
            e.target.classList.toggle('fa-eye-slash')
            senha.type = senha.type == "password" ? "text" : "password";
        });
    </script>
</body>

</html>
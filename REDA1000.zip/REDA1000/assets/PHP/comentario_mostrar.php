<?php

require_once('conexao.php');

$id_publicacao = $_POST['idpublicacao'];
$conteudo = "";
$usuarios = [];

$sql = "SELECT * FROM usuario";
$resultado = $banco->query($sql);
while($row = $resultado->fetch_assoc()){
   $usuarios[] = $row;
}

function usuarios($usuarios, $id, $value){
    foreach($usuarios as $usuario):
        if($usuario['id'] == $id){
            $var = $usuario["$value"];
            break;
        }
    endforeach;
    return $var;
}
//Faço uma consulta de todos os comentarios tem que o id da publicação que veio pelo ajax JAVASCRIPT
$sql = "SELECT * FROM comentario WHERE id_publicacao = '$id_publicacao'";
$resultado = $banco->query($sql);
if ($resultado->num_rows > 0) {
  while($row = $resultado->fetch_assoc()){
    $nome = usuarios($usuarios, $row['id_comentou'], 'nome');
    $foto = usuarios($usuarios, $row['id_comentou'], 'foto');
    $status = "sucess";
    $conteudo .=
    "<div class='comentarios-conteudo'>
<div class='comentarios-img'>
    <img src='./assets/IMG/PERFIL/{$foto}' alt='foto de perfil'>      
</div>
<div class='comentarios-texto'>
    <h3>{$nome}</h3>
    <p>{$row['texto']}</p>
</div>
</div>";
  }
} else {
    $status = "sucess";
    $conteudo = "<div class='comentarios-conteudo'><p>Nenhum comentário encontrado</p></div>";
}

exit(json_encode(array("status" => $status,"conteudo" => $conteudo)));

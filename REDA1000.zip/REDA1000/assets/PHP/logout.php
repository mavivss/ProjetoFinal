<?php
session_start();
session_destroy();
setcookie("hash", null, null, "/");
header("location: ../../index.php");

//Destruo todas as sessões e todos os cookies
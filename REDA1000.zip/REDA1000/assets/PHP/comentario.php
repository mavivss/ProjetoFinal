<?php

session_start();

require_once('conexao.php');

//Valido todos os dados que serão armazenado no banco, para evitar problemas futuros
$id = $_SESSION['id'];
$id_publicacao = trim(addslashes(htmlspecialchars($_POST['idpublicacao'])));
$texto = trim(addslashes(htmlspecialchars($_POST['texto'])));

//Faço uma consulta das minhas informações para saber o total de pontuação que eu tenho no ranking e acrescenta mais um  ponto quando eu cadastrar o comentario
$sqlSelect = "SELECT * FROM usuario WHERE id = '$id'";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    //Pegando o total de pontos do ranking e colocando na variavel $pontos
    $pontos = $linhas['pontuacao'];  
}
//Faço outra validação pra saber se o conteudo do texto é maior que zero
if(strlen($texto) > 0){
    //Insiro o comentario dessa usuario no banco de dados
    $sqlInserir = "INSERT INTO comentario (id_publicacao, id_comentou, texto)
    VALUES ('$id_publicacao','$id','$texto')";
    $respostaInserir = $banco->query($sqlInserir);
    if ($respostaInserir) {
        //valido de o comentario foi inserido com sucesso, se foi, modifique a tabela usuario no atributo pontuacao e adiciona o novo valor
        $response = "sucess";
        $pontos = $pontos + 1; //aumentando o valor dos pontos do usuario
        $sql = "UPDATE usuario SET pontuacao = '$pontos' WHERE id = '$id'";
        $banco->query($sql);
    } else {
        $response = "failed";
    }
}
exit(json_encode(array("status" => $response)));
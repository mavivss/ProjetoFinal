<?php
session_start();

require_once('conexao.php');

//Recebos todas as informações dos materias e valido para evitar problemas no futuro
$titulo = trim(addslashes(htmlspecialchars($_POST['titulo-pEditor'])));
$texto = trim(addslashes($_POST['redacao-pEditor']));
$foto = $_FILES['foto-pEditor']['name'];
$pdf = $_FILES['pdf-pEditor']['name'];
$id = $_SESSION['id'];
//pego a extensão da imagem e pdf
$extensaoImg = pathinfo($foto, PATHINFO_EXTENSION);
$extensaoPdf = pathinfo($pdf, PATHINFO_EXTENSION);
$postagem = true;

//verifico se todas as informações são vazias, se for, não faço upload, pq precisamos de todas as informações
if ((empty($titulo) or empty($texto)) or empty($foto) or empty($pdf)) {
    $postagem = false;
    header("location: ../../perfil.php");
}
if ($postagem) {
    $pasta = '../IMG/MATERIAL/';// diretorio que ficará as imagens dos materiais
    $pastapdf = '../IMG/MATERIAL/PDF/';// diretorio que ficará os PDF dos materiais
    //Crio um novo nome pro PDF e IMAGEM
    $nome_img = "Imagem". $id . time() . "." . $extensaoImg; 
    $nome_pdf = "PDF". $id . time() . "." . $extensaoPdf;
    //Faço upload
    if (move_uploaded_file($_FILES['foto-pEditor']['tmp_name'], $pasta . $nome_img) AND move_uploaded_file($_FILES['pdf-pEditor']['tmp_name'], $pastapdf . $nome_pdf)) {
        $sql = "INSERT INTO `material` (`dono`, `titulo`,`descricao`, `foto`, `pdf`) VALUES 
        ('$id', '$titulo','$texto', '$nome_img', '$nome_pdf')";
        $banco->query($sql);
        header("location: ../../perfil.php");
    }
}
$banco->close();

<?php
session_start();
require_once("conexao.php");
$idPst = trim(addslashes(htmlspecialchars($_GET['idpublicacao'])));
$id = $_SESSION['id'];

$sqlSelect = "SELECT * FROM redacao WHERE id_redacao = '{$idPst}'";
$result = $banco->query($sqlSelect);
if ($result->num_rows > 0) {
    $valor = $result->fetch_assoc();
    if ($valor['dono'] == $id) {
        $sqlRedacao = "DELETE FROM redacao WHERE id_redacao = '$idPst'";
        $banco->query($sqlRedacao);
        $sqlComentario = "DELETE FROM comentario WHERE id_publicacao = '$idPst'";
        $banco->query($sqlComentario);
        $sqlCurtida = "DELETE FROM curtida WHERE id_publicacao = '$idPst'";
        $banco->query($sqlCurtida);
        header("location: ../../index.php");
    } else {
        header("location: ../../index.php");
    }
} else {
   header("location: ../../index.php");
}
$banco->close();

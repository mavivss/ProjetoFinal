<?php
require_once("conexao.php");

//Esse count é pq as imagens estão nomeadas com o nome ranking1,ranking2,ranking3... Assim, eu posso mostrar a recompensa para o usuario de um feito mais simples
$count = 1;

//Consultar os 15 primeiros usuarios odernado pela pontuação, os que tem uma maior pontuação.
$sqlSelect = 'SELECT * FROM usuario ORDER BY pontuacao DESC LIMIT 15';
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    echo "<div class='ranking-conteudo'>
    <div class='ranking-people'>
        <div class='ranking-img'>
            <img src='./assets/IMG/PERFIL/{$linhas['foto']}' alt='foto de perfil'>
        </div>
        <div class='ranking-texto'>
            <h2>{$linhas['nome']}</h2>
        </div>
        <div class='ranking-pontuacao'>
            <p>{$linhas['pontuacao']}</p>
        </div>
        <div class='ranking-premio'>
            <p><img src='./assets/IMG/SITE/ranking{$count}.png' alt='premio'></p>
        </div>
    </div>
    </div>";
    $count++;
}
<?php
session_start();
require_once('conexao.php');

$nome = trim(addslashes(htmlspecialchars($_POST['name'])));
$email = trim(addslashes(htmlspecialchars($_POST['email'])));
$bio = trim(addslashes(htmlspecialchars($_POST['bio']))) ?? "";
$id = $_SESSION['id'];

$sqlSelect = "SELECT * FROM usuario WHERE id = '$id'";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $pontos = $linhas['pontuacao'];
}
$pontos = $pontos + 1;

//Verifico se o nome e email tem algo escrito e se tiver, quero modificar a tabela usuario e inserir o novo email ou nome
if (!empty($nome) AND !empty($email)) {
        $sql = "UPDATE usuario SET  nome = '$nome', email = '$email', bio='$bio', pontuacao='$pontos' WHERE id = '$id'";
        $banco->query($sql);
        $_SESSION['alert'] = "Informações modificada com sucesso";
        header("location: ../../perfil.php");
}
else{
    $_SESSION['alert'] = "Não conseguimos modificar suas informações";
    header("location: ../../perfil.php");   
}
$banco->close();

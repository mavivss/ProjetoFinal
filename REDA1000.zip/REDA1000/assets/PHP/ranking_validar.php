<?php

//require_once("conexao.php");
//Tempo que será armazenado no banco de 1 semana, assim, quando passar 1 semana, os valores de pontuação voltar a ser zero
$time_final = time() + (86400 * 7);
$time = time(); 
$tempo = 0;
$sqlSelect = "SELECT * FROM ranking";
$result = $banco->query($sqlSelect);
$linhas = $result->fetch_assoc();

//Verificando se já passou 1 semana para limpar as pontuações de todos os usuarios
if ($linhas['time_final'] <= $time) {
    $atualizar = "UPDATE ranking SET time_final='{$time_final}'";
    $result = $banco->query($atualizar);
    if ($result) {
        $atualizarUsuarios = "UPDATE usuario SET pontuacao='$tempo'";
        $banco->query($atualizarUsuarios);
    }
}


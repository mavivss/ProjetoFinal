<?php
require_once("conexao.php");

//Tipo 1, significado que este usuario não está logado
$tipo = 1;

$id = @$_SESSION['id'];
$query = $_GET['query'];
$usuarios = [];
$postagens = [];
$curtidas = [];

//verifico se está um cookie hash
if (!empty($_COOKIE['hash'])) {
    $sqlSelect = "SELECT * FROM usuario";
    $result = $banco->query($sqlSelect);
    while ($linhas = $result->fetch_assoc()) {
        //verifico se o cookie hash que está o ID é igual a um ID que está no banco
        $condicao = password_verify($linhas['id'], $_COOKIE['hash']) ? true : false;
        if ($condicao) {
            //Tipo 2, significado que este usuario está logado
            $tipo = 2;
            break;
        }
    }
}

$sqlSelect = "SELECT * FROM usuario ORDER BY id DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $usuarios[] = $linhas;
}
//Mostrar as informações que usuario pesquisar pelo meotodo LIKE do SQL, as informações do titulo e texto
$sqlSelect = "SELECT * FROM redacao WHERE titulo LIKE '%$query%' OR texto LIKE '%$query%' ORDER BY id_redacao DESC";
$result = $banco->query($sqlSelect);
if ($result->num_rows > 0) {
    while ($linhas = $result->fetch_assoc()) {
        $postagens[] = $linhas;
    }
} else {
    echo "<div class='redacao'>
    <div class='texto'>
    <div class='texto-redacao'>Nenhuma postagem encontrada</div>
    </div>
    </div>";
}

//Consulto a tabela curtida, caso o usuario tenha curtido mostrar na tela
$sqlSelect = "SELECT * FROM curtida ORDER BY id_curtida DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $curtidas[] = $linhas;
}

//Função para validar se o usuario que está logado já curtiu aquela publicação
function curtidas($curtidas, $idpostagem, $id)
{
    $var = false;
    foreach ($curtidas as $curtida) :
        ///verificação pelo id da postagem e o ID da pessoa que está logada
        if ($curtida['id_publicacao'] == $idpostagem and $curtida['id_click'] == $id) {
            $var = true;
            break;
        } else {
            $var = false;
        }
    endforeach;
    return $var;
}
foreach ($postagens as $postagem) :
    foreach ($usuarios as $user) :
    //Pegando a foto e nome do usuario:
        if ($user['id'] == $postagem['dono']) {
            $nome_publicacao = $user['nome'];
            $foto_publicacao = $user['foto'];
        }
    endforeach;
    //Verificando se o usuario já curtiu e adicionar a CLASS btnCurtida que já tem com alguns efeitos CSS
    $curtidaclick = curtidas($curtidas, $postagem['id_redacao'], $id) ? " btnCurtida" : "";
    $titulo = strlen($postagem['titulo']) > 0 ? "<p class='titulo'>{$postagem['titulo']}</p>" : "";
    $redacao = strlen($postagem['texto']) > 0 ? "<div class='texto-redacao'>{$postagem['texto']}</div>" : "";
    $imagem = strlen($postagem['imagem']) > 0 ? "<div class='foto-redacao'><img src='assets/IMG/POSTAGEM/{$postagem['imagem']}' alt='foto da publicação'></div>" : "";
    $idpublicacao = $postagem['id_redacao'];
    if($tipo == 2){
    echo "<div class='redacao'>
<div class='foto'>
    <img src='./assets/IMG/PERFIL/{$foto_publicacao}' alt='foto de perfil'>
</div>
<div class='texto'>
    <h3 class='nome'>{$nome_publicacao}</h3>
    {$titulo}{$redacao}{$imagem}
    <div class='opcao-redacao'>
        <div class='btn-redacao'>
            <button class='curtirfoto{$curtidaclick}' data-id='{$idpublicacao}'>Curtir</button>
        </div>
        <div class='btn-redacao'>
            <button data-id='{$idpublicacao}' class='btncomentario'>Comentar</button>
        </div>
    </div>
    <div class='comentariofoto{$idpublicacao} comentario'>
        <form class='formcomentario' action='assets/PHP/comentario.php' method='post'>
            <div class='comentario-img'>
                <img src='./assets/IMG/PERFIL/perfil.png' alt='foto de perfil'>
            </div>
            <div class='comentario-conteudo'>
                <div class='comentario-texto'>
                    <input placeholder='Escreva um comentário' type='text' class='coment{$idpublicacao}' name='textoComent' id='textoComent'>
                    <button data-id='{$idpublicacao}'><i data-id='{$idpublicacao}' class='fas fa-paper-plane'></i></button>
                </div>
            </div>
        </form>
        <div id='comment'>
            <div class='loading-conteudo'>
                <img class='loading' src='./assets/IMG/SITE/loading-buffering.gif' alt='carregando...'>
            </div>
        </div>
    </div>
</div>
</div>";
    }else{
        echo "<div class='redacao'>
        <div class='foto'>
            <img src='./assets/IMG/PERFIL/{$foto_publicacao}' alt='foto'>
        </div>
        <div class='texto'>
        <h3 class='nome'>{$nome_publicacao}</h3>
        {$titulo}{$redacao}{$imagem}
        </div>
        </div>";
    }
endforeach;

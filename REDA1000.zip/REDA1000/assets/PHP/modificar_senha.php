<?php
session_start();
require_once('conexao.php');

$senhaAtual = trim(addslashes(htmlspecialchars($_POST['senhaAtual'])));
$senhaNova = trim(addslashes(htmlspecialchars($_POST['senhaNova'])));
$id = $_SESSION['id'];
$confirma = false;

$sqlSelect = "SELECT * FROM usuario WHERE id = '$id'";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $pontos = $linhas['pontuacao'];
    //Valido se a senha atual que está no banco é igual a senha que o usuario enviou pelo metodo POST
    if(password_verify($senhaAtual, $linhas['senha'])){
        $confirma = true; //na variavel confirma eu digo que é verdadeira pra poder usar a proxima condição
        $senhaNova = password_hash($senhaNova, PASSWORD_DEFAULT); //criptografo a nova senha que sera armazenada no banco
    }
}
$pontos = $pontos + 1;


if (!empty($senhaAtual) AND !empty($senhaNova) AND $confirma) {
    //Modifico a senha
        $sql = "UPDATE usuario SET  senha = '$senhaNova', pontuacao='$pontos' WHERE id = '$id'";
        $banco->query($sql);
        $_SESSION['alert'] = "Senha modificada com sucesso";
        header("location: ../../perfil.php");
}
else{
    $_SESSION['alert'] = "Informações invalidas";
    header("location: ../../perfil.php");   
}
$banco->close();

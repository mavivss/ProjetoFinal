<?php
require_once("conexao.php");

$id = @$_SESSION['id'];
$usuarios = [];
$postagens = [];
$sqlSelect = "SELECT * FROM usuario ORDER BY id DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $usuarios[] = $linhas;
}
$sqlSelect = "SELECT * FROM redacao ORDER BY id_redacao DESC";
$result = $banco->query($sqlSelect);
if($result->num_rows > 0){
while ($linhas = $result->fetch_assoc()) {
    $postagens[] = $linhas;
}
}else{
    echo "<div class='redacao'>
    <div class='texto'>
    <div class='texto-redacao'>Nenhuma postagem encontrada</div>
    </div>
    </div>";
}


foreach ($postagens as $postagem) :
    foreach ($usuarios as $user) :
        if ($user['id'] == $postagem['dono']) {
            $nome_publicacao = $user['nome'];
            $foto_publicacao = $user['foto'];
        }
    endforeach;
       $texto = str_replace("\r\n<br>\r\n", "<br><br>", $postagem['texto']);
    $titulo = strlen($postagem['titulo']) > 0 ? "<p class='titulo'>{$postagem['titulo']}</p>" : "";
    $redacao = strlen($postagem['texto']) > 0 ? "<div class='texto-redacao'>{$texto}</div>" : "";
    $imagem = strlen($postagem['imagem']) > 0 ? "<div class='foto-redacao'><img src='./assets/IMG/POSTAGEM/{$postagem['imagem']}' alt='foto'></div>" : "";
    $idpublicacao = $postagem['id_redacao'];

    echo "<div class='redacao'>
<div class='foto'>
    <img src='./assets/IMG/PERFIL/{$foto_publicacao}' alt='foto'>
</div>
<div class='texto'>
<h3 class='nome'>{$nome_publicacao}</h3>
{$titulo}{$redacao}{$imagem}
</div>
</div>";
endforeach;

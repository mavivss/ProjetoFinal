<?php
session_start();
require_once('conexao.php');

//Pegando o id do usuario que deseja deletar sua conta, pra remover todas as informações dele em todas as tabelas
$id = $_SESSION['id'];

$sqlUsuario = "DELETE FROM usuario WHERE id = '$id'";
$banco->query($sqlUsuario);
$sqlRedacao = "DELETE FROM redacao WHERE dono = '$id'";
$banco->query($sqlRedacao);
$sqlMaterial = "DELETE FROM material WHERE dono = '$id'";
$banco->query($sqlMaterial);
$sqlComentario = "DELETE FROM comentario WHERE id_comentou = '$id'";
$banco->query($sqlComentario);
$sqlCurtida = "DELETE FROM curtida WHERE id_click = '$id'";
$banco->query($sqlCurtida);
$banco->close();

//Levar ele pra arquivo de logout.php e remover o cookie e a sessão dele
header("location: logout.php");





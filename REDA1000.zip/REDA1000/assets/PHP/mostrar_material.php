<?php
require_once("conexao.php");

$postagens = [];
$principal = true;

//Faço uma consulta em todos os materiais que os ADMINISTRADORES adicionaram
$sqlSelect = "SELECT * FROM material ORDER BY id DESC";
$result = $banco->query($sqlSelect);
if ($result->num_rows > 0) {
    while ($linhas = $result->fetch_assoc()) {
        $postagens[] = $linhas;
    }
}
//Precorro um array, pra mostrar os materiais no site
foreach ($postagens as $postagem) :
    if ($principal) {
        //Insiro primeiro a imagem maior
        echo "<a href='./assets/IMG/MATERIAL/PDF/{$postagem['pdf']}' download='{$postagem['titulo']}'><div class='conteudo-principal'>
            <img src='./assets/IMG/MATERIAL/{$postagem['foto']}' alt='foto do material'>
            <h4>{$postagem['titulo']}</h4>
            <p>{$postagem['descricao']}</p>
        </div></a>";
        //apos inserir a imagem maior, eu digo que essa codigo é falso, pra nn entrar mais nela e sempre partir pro ELSE, mostrando os materiais pequenos
        $principal = false;
    } else {
        echo "<a href='./assets/IMG/MATERIAL/PDF/{$postagem['pdf']}' download='{$postagem['titulo']}'><div class='conteudo-restante'>
        <div class='conteudo-img'>
        <img src='./assets/IMG/MATERIAL/{$postagem['foto']}' alt='foto do material'>
        </div>
        <div class='conteudo-texto'>
        <h4>{$postagem['titulo']}</h4>
        <p>{$postagem['descricao']}</p>
        </div>
    </div></a>";
    }
endforeach;

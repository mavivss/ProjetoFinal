<?php
session_start();
require_once('conexao.php');

//valido as informações
$foto = trim(addslashes(htmlspecialchars($_FILES['fotoperfil']['name']))) ?? "";
$id = $_SESSION['id'];
//pego a extensão da foto
$extensao = pathinfo($foto, PATHINFO_EXTENSION);
//consulta pra adicionar ponto pro usuario
$sqlSelect = "SELECT * FROM usuario WHERE id = '$id'";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $pontos = $linhas['pontuacao'];
}
$pontos = $pontos + 1;

//Valido se existe alguma foto pra fazer upload
if (!empty($foto)) {
    $pasta = '../IMG/PERFIL/';
    $nome_foto = $id . time() . "." . $extensao;
    if (move_uploaded_file($_FILES['fotoperfil']['tmp_name'], $pasta . $nome_foto)) {
        $sql = "UPDATE usuario SET  foto = '$nome_foto', pontuacao = '$pontos' WHERE id = '$id'";
        $resposta = $banco->query($sql);
        if($resposta){
            $status = "Sucess";
            $mensagem = "Foto enviada com sucesso";
        }else{
            $status = "Falid";
            $mensagem = "Não conseguimos enviar essa foto";
        }
        
    }else{
        $status = "Falid";
        $mensagem = "Não conseguimos enviar essa foto";
    }
}
exit(json_encode(array("status" => $status, "mensagem" => $mensagem)));
$banco->close();

<?php
//Iniciar a sessão PHP
session_start();
//Inserir a conexão com o banco de dados nesse arquivo
require_once('../conexao.php');

//Pegar a variavel de sessao, cujo valor seja o ID
$id = $_SESSION['id'];
//Criar arrays para armazenar as informações do banco de dado nelas
$comentarios = [];
$postagens = [];
$usuarios = [];
$conteudo = "";

//Consultar todos os comentarios onde o id_comentou seja do usuario que está logado
$sqlSelect = "SELECT * FROM comentario WHERE id_comentou = '$id' GROUP BY id_publicacao ORDER BY id_comentario DESC";
$result = $banco->query($sqlSelect);
//Verificar se existe comentarios no banco de dados, caso contrario mostre as informações que está no ELSE
if ($result->num_rows > 0) {
    while ($linhas = $result->fetch_assoc()) {
        $comentarios[] = $linhas;
    }
} else {
    $conteudo = "<div class='redacao'>
    <div class='texto'>
    <div class='texto-redacao'>Nenhuma postagem encontrada</div>
    </div>
    </div>";
}
//Consultar as informações do usuario, pra poder usar a foto e nome dele
$sqlSelect = "SELECT * FROM usuario ORDER BY id DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $usuarios[] = $linhas;
}
//Consultar todas as redações
$sqlSelect = "SELECT * FROM redacao ORDER BY id_redacao DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $postagens[] = $linhas;
}
//Função para pegar a foto e o nome do usuario
function pessoas($usuarios, $dono, $value)
{
    foreach ($usuarios as $user) :
        if ($user['id'] == $dono) {
            $var = $user["$value"];
            break;
        }
    endforeach;
    return $var;
}
//Precorrer array dos comentarios
foreach ($comentarios as $comentario) :
    foreach ($postagens as $postagem) :
        //Verifico as postagens que tem meu id nos comentarios
        if ($comentario['id_publicacao'] == $postagem['id_redacao']) {
            //Pego o nome do usuario que postou aquela publicacao
            $nome_publicacao = pessoas($usuarios, $postagem['dono'], 'nome');
            //Pego a foto do usuario que postou aquela publicacao
            $foto_publicacao = pessoas($usuarios, $postagem['dono'], 'foto');
            //Valido as informações para apresentar no perfil
            $titulo = strlen($postagem['titulo']) > 0 ? "<p class='titulo'>{$postagem['titulo']}</p>" : "";
            $redacao = strlen($postagem['texto']) > 0 ? "<div class='texto-redacao'>{$postagem['texto']}</div>" : "";
            $imagem = strlen($postagem['imagem']) > 0 ? "<div class='foto-redacao'> <img src='./assets/IMG/POSTAGEM/{$postagem['imagem']}' alt='foto'></div>" : "";
            $conteudo .= "<div class='redacao'><div class='foto'><img src='./assets/IMG/PERFIL/{$foto_publicacao}' alt='foto'></div><div class='texto'><h3 class='nome'>{$nome_publicacao}</h3>{$titulo}{$redacao}{$imagem}</div></div>";
        }
    endforeach;
endforeach;
//Mando as informações pelo JSON e recebendo no javascript pelo AJAX
exit(json_encode(array("conteudo" => $conteudo)));

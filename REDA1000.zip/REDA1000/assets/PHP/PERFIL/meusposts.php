<?php
session_start();
require_once('../conexao.php');

$id = $_SESSION['id'];
$conteudo = "";
//Consulto todas as minhas redações, que tem o meu id no atributo DONO
$sqlSelect = "SELECT * FROM redacao WHERE dono = '$id' ORDER BY id_redacao DESC";
$result = $banco->query($sqlSelect);

if($result->num_rows > 0){
while ($linhas = $result->fetch_assoc()) {
    $nome_publicacao = $_SESSION['nome']; //Já que será somente as minhas redações, não uso função e apenas acrescento meu nome e depois minha foto
    $foto_publicacao = $_SESSION['foto'];
    $titulo = strlen($linhas['titulo']) > 0 ? "<p class='titulo'>{$linhas['titulo']}</p>" : "";
    $redacao = strlen($linhas['texto']) > 0 ? "<div class='texto-redacao'>{$linhas['texto']}</div>" : "";
    $imagem = strlen($linhas['imagem']) > 0 ? "<div class='foto-redacao'> <img src='./assets/IMG/POSTAGEM/{$linhas['imagem']}' alt='foto'></div>" : "";
    $idpublicacao = $linhas['id_redacao'];
    $conteudo .= "<div class='redacao'><div class='foto'><img src='./assets/IMG/PERFIL/{$foto_publicacao}' alt='foto'></div><div class='texto'><h3 class='nome'>{$nome_publicacao}</h3>{$titulo}{$redacao}{$imagem}</div></div>";

}
}else{
$conteudo = "<div class='redacao'>
    <div class='texto'>
    <div class='texto-redacao'>Nenhuma postagem encontrada</div>
    </div>
    </div>";
}



exit(json_encode(array("conteudo" => $conteudo)));


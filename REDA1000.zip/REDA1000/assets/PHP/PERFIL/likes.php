<?php
session_start();

require_once('../conexao.php');

$id = $_SESSION['id'];
$curtidas = [];
$postagens = [];
$usuarios = [];
$conteudo = "";

//Consulto todas se na tabela curtida tem algum informação com o meu ID
$sqlSelect = "SELECT * FROM curtida WHERE id_click = '$id' ORDER BY id_curtida DESC";
$result = $banco->query($sqlSelect);
//Procuro saber se a tebela tem informações, caso contrario apresento o que está no ELSE, informando que eu não curtir nada
if ($result->num_rows > 0) {
    while ($linhas = $result->fetch_assoc()) {
        $curtidas[] = $linhas;
    }
} else {
    $conteudo = "<div class='redacao'>
    <div class='texto'>
    <div class='texto-redacao'>Nenhuma postagem encontrada</div>
    </div>
    </div>";
}
$sqlSelect = "SELECT * FROM usuario ORDER BY id DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $usuarios[] = $linhas;
}
$sqlSelect = "SELECT * FROM redacao ORDER BY id_redacao DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $postagens[] = $linhas;
}

function pessoas($usuarios,$dono, $value){
    foreach ($usuarios as $user) :
        if ($user['id'] == $dono) {
            return $user["$value"];
        }
    endforeach;
}

foreach ($curtidas as $curtida) :
    foreach ($postagens as $postagem) :
        if ($curtida['id_publicacao'] == $postagem['id_redacao']) {
            $nome_publicacao = pessoas($usuarios, $postagem['dono'], 'nome');
            $foto_publicacao = pessoas($usuarios, $postagem['dono'], 'foto');
            $titulo = strlen($postagem['titulo']) > 0 ? "<p class='titulo'>{$postagem['titulo']}</p>" : "";
            $redacao = strlen($postagem['texto']) > 0 ? "<div class='texto-redacao'>{$postagem['texto']}</div>" : "";
            $imagem = strlen($postagem['imagem']) > 0 ? "<div class='foto-redacao'> <img src='./assets/IMG/POSTAGEM/{$postagem['imagem']}' alt='foto'></div>" : "";
            $conteudo .= "<div class='redacao'><div class='foto'><img src='./assets/IMG/PERFIL/{$foto_publicacao}' alt='foto'></div><div class='texto'><h3 class='nome'>{$nome_publicacao}</h3>{$titulo}{$redacao}{$imagem}</div></div>";
        }
    endforeach;
endforeach;

exit(json_encode(array("conteudo" => $conteudo)));

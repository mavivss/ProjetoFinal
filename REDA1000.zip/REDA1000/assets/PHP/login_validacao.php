<?php

require_once("conexao.php");
//Pego as informações que veio da tela de login
$email = trim(addslashes(htmlspecialchars($_POST['email'])));
$senha = trim(addslashes(htmlspecialchars($_POST['senha'])));
$erro = true;

//Faço uma consulta de todos os usuarios
$sqlSelect = "SELECT * FROM usuario";
$result = $banco->query($sqlSelect);

//Crio uma laço de repetição pra saber se existe as informações que o usuario digitou no banco de dados, 
while ($linhas = $result->fetch_assoc()) {
    //Verifico se existe um email igual a que o usuario informacou e descriptografo a senha e verifico se existe uma senha igual ao que o usuario digitou
    if (($linhas['email'] == $email) AND password_verify($senha, $linhas['senha'])) {
        //criptografo o ID para usar como sessão dos logados
        $cookie = password_hash($linhas['id'], PASSWORD_DEFAULT);
        //adiciono esse ID em um cookie que usuaremos mais pra frente para validar se este usuario pode ficar na tela dos logados ou não
        setcookie("hash", "$cookie", time() + 3600 * 60 * 60 * 60, "/");
        $erro = false;
        header("location: ../../index.php");
    }
}
if ($erro) {
    header("location: ../../login.php");
}

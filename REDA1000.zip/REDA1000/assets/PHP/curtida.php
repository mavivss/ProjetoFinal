<?php
session_start();

require_once('conexao.php');

$curtidas = [];
$id = $_SESSION['id'];
$id_publicacao = $_POST['idpublicacao'];
$respostaDelete = true;
$resultado = "";

//Pegando meus pontos do ranking pra adicionar mais 1 ponto
$sqlSelect = "SELECT * FROM usuario WHERE id = '$id'";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $pontos = $linhas['pontuacao'];  
}
//Armazenando todas as curtidas no array, pra verificar depois se este usuario ja curtiu a publicação deseja, se já, delete a curtida dele, caso contrario adicione a curtida
$sql = "SELECT * FROM curtida";
$resposta = $banco->query($sql);
if($resposta->num_rows > 0){
    while($row = $resposta->fetch_assoc()){
        $curtidas[] = $row;
    }
}

foreach($curtidas as $curtida):
    //Fazendo validação pra saber se este usuario já curtiu a publicação que ele informou, caso ja tenha curtido, delete está curtida
    if($curtida['id_publicacao'] == $id_publicacao AND $curtida['id_click'] == $id){
        $sqlDeletar = "DELETE FROM curtida WHERE (id_publicacao = '$id_publicacao' AND id_click='$id')";    
        $respostaDelete = $banco->query($sqlDeletar);
        $resultado = "Você deixou de curtir uma foto";
        if($respostaDelete){
            //Verificando o total de pontuação é maior que zero, pq se não o usuario pode ficar com uma pontuação negativa
            if($pontos > 0){
                //minimua 1 ponto desse usuario por ter deixado de curtir uma publicação
            $pontos = $pontos - 1;
            $sql = "UPDATE usuario SET pontuacao = '$pontos' WHERE id = '$id'";
            $banco->query($sql);
            }
        }
        $respostaDelete = false;
    }
endforeach;

if($respostaDelete){
    //se o usuario ainda não curtiu, insira a curtida dele no banco de dados
    $sqlInserir = "INSERT INTO curtida (id_publicacao, id_click)
    VALUES ('$id_publicacao','$id')";
    $respostaInserir = $banco->query($sqlInserir);
    $resultado = "Você curtiu uma foto";
    if($respostaInserir){
        //adicione 1 ponto a ele por ter curtido uma publicação
        $pontos = $pontos + 1;
        $sql = "UPDATE usuario SET pontuacao = '$pontos' WHERE id = '$id'";
        $banco->query($sql);
    }
}

if ($respostaDelete OR $respostaInserir) {
    $response = "sucess";
} else {
    $response = "failed";
}

exit(json_encode(array("status" => $response,"resultado" => $resultado)));

<?php
require_once("conexao.php");

$id = $_SESSION['id'];
$usuarios = [];
$postagens = [];
$curtidas = [];

$sqlSelect = "SELECT * FROM usuario WHERE id='$id' ORDER BY id DESC";
$result = $banco->query($sqlSelect);
$linhas = $result->fetch_assoc();
$fotoUsuario = $linhas['foto'];


$sqlSelect = "SELECT * FROM usuario ORDER BY id DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $usuarios[] = $linhas;
}
$sqlSelect = "SELECT * FROM redacao ORDER BY id_redacao DESC";
$result = $banco->query($sqlSelect);
if ($result->num_rows > 0) {
    while ($linhas = $result->fetch_assoc()) {
        $postagens[] = $linhas;
    }
} else {
    echo "<div class='redacao'>
    <div class='texto'>
    <div class='texto-redacao'>Nenhuma postagem encontrada</div>
    </div>
    </div>";
}


$sqlSelect = "SELECT * FROM curtida ORDER BY id_curtida DESC";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $curtidas[] = $linhas;
}
function curtidas($curtidas, $idpostagem, $id)
{
    $var = false;
    foreach ($curtidas as $curtida) :
        if ($curtida['id_publicacao'] == $idpostagem and $curtida['id_click'] == $id) {
            $var = true;
            break;
        } else {
            $var = false;
        }
    endforeach;
    return $var;
}
foreach ($postagens as $postagem) :
    $delete = "";
    foreach ($usuarios as $user) :
        if ($user['id'] == $postagem['dono']) {
            $nome_publicacao = $user['nome'];
            $foto_publicacao = $user['foto'];
        }
    endforeach;

    $curtidaclick = curtidas($curtidas, $postagem['id_redacao'], $id) ? " btnCurtida" : "";
    $titulo = strlen($postagem['titulo']) > 0 ? "<p class='titulo'>{$postagem['titulo']}</p>" : "";
    $redacao = strlen($postagem['texto']) > 0 ? "<div class='texto-redacao'>{$postagem['texto']}</div>" : "";
    $imagem = strlen($postagem['imagem']) > 0 ? "<div class='foto-redacao'><img src='assets/IMG/POSTAGEM/{$postagem['imagem']}' alt='foto da publicação'></div>" : "";
    $idpublicacao = $postagem['id_redacao'];
    $delete = $postagem['dono'] == $id? "<div class='deletePub' data-id='$idpublicacao'><i class='delete-pub fas fad fa-angle-down'><div class='deletePub-m deleta-$idpublicacao'><i class='fas fa-trash'></i><a href='assets/PHP/deletarPostagens.php?idpublicacao={$postagem['id_redacao']}&dir=home'>Deletar</a></div></i></div>" : "";
 
     
    echo "<div class='redacao'>
    {$delete}
<div class='foto'>
    <img src='./assets/IMG/PERFIL/{$foto_publicacao}' alt='foto de perfil'>
</div>
<div class='texto'>
    <h3 class='nome'>{$nome_publicacao}</h3>
    {$titulo}{$redacao}{$imagem}
    <div class='opcao-redacao'>
        <div class='btn-redacao'>
            <button class='curtirfoto{$curtidaclick}' data-id='{$idpublicacao}'>Curtir</button>
        </div>
        <div class='btn-redacao'>
            <button data-id='{$idpublicacao}' class='btncomentario'>Comentar</button>
        </div>
    </div>
    <div class='comentariofoto{$idpublicacao} comentario'>
        <form class='formcomentario' action='assets/PHP/comentario.php' method='post'>
            <div class='comentario-img'>
                <img src='./assets/IMG/PERFIL/{$fotoUsuario}' alt='foto de perfil'>
            </div>
            <div class='comentario-conteudo'>
                <div class='comentario-texto'>
                    <input placeholder='Escreva um comentário' type='text' class='coment{$idpublicacao}' name='textoComent' id='textoComent'>
                    <button data-id='{$idpublicacao}'><i data-id='{$idpublicacao}' class='fas fa-paper-plane'></i></button>
                </div>
            </div>
        </form>
        <div id='comment'>
            <div class='loading-conteudo'>
                <img class='loading' src='./assets/IMG/SITE/loading-buffering.gif' alt='carregando...'>
            </div>
        </div>
    </div>
</div>
</div>";
endforeach;

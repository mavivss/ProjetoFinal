<?php
session_start();
require_once('conexao.php');

//Validando todas informações que será inseridas no banco de dados 
$titulo = trim(addslashes(htmlspecialchars($_POST['titulo-pEditor']))) ?? "";
$texto = trim(addslashes(htmlspecialchars($_POST['redacao-pEditor']))) ?? "";
//$texto = $_POST['redacao-pEditor'] ?? "";
$foto = $_FILES['foto-pEditor']['name'] ?? "";
$tz = new DateTimeZone('America/Sao_Paulo');
$tzAtual = new DateTime(null, $tz);
$data = $tzAtual->format('Y:m:d H:i:s');
$id = $_SESSION['id'];$postagem = true;
//pegando a extensão da foto que o usuario deseja fazer upload
$extensao = pathinfo($foto, PATHINFO_EXTENSION);
$pontos = "";

//Consultando os pontos desse usuario, pra adicionar mais 1 ponto depois que ele fizer upload
$sqlSelect = "SELECT * FROM usuario WHERE id = '$id'";
$result = $banco->query($sqlSelect);
while ($linhas = $result->fetch_assoc()) {
    $pontos = $linhas['pontuacao'];  
}
$pontos = $pontos + 1;

//Validando se todas as informações são fazias, lembre-se, precisando que pelo menos 1 campo tenha informação, caso contrario não iremos inserir nada
if ((empty($titulo) AND empty($texto)) AND empty($foto)) {
    $postagem = false;
    header("location: ../../index.php");
}
if ($postagem) {
    //Digo o diretorio que as imagens das postagens serão armazenas
    $pasta = '../IMG/POSTAGEM/';
    //Crio um novo nome pra esta imagem, usando meu ID, o TEMPO em horas e concateno com a extensão
    $nome_final = $id . time() .".". $extensao;
    //valido se tem alguma imagem pra entrar na condição
    if (strlen($foto) > 0) {
        //Faço upload da imagem, mostrando as informações dele, a pasta e novo nome dela
        if (move_uploaded_file($_FILES['foto-pEditor']['tmp_name'], $pasta . $nome_final)) {
            $sql = "INSERT INTO `redacao` (`dono`, `titulo`,`texto`, `imagem`, `data`) VALUES 
        ('$id', '$titulo','$texto', '$nome_final', '$data')";
            $resultado = $banco->query($sql);
            if($resultado){
                $sql = "UPDATE usuario SET pontuacao = '$pontos' WHERE id = '$id'";
                $banco->query($sql);
                header("location: ../../index.php");
            }else{
                header("location: ../../index.php");
            }
        }
    } else {
        //se não houver imagem, informo que o campo de imagem será vazio e adiciono somente o texto
        $nome_final = "";
        $sql = "INSERT INTO `redacao` (`dono`,`titulo`, `texto`, `imagem`, `data`) VALUES 
    ('$id', '$titulo', '$texto', '$foto', '$data')";
     $resultado = $banco->query($sql);
     if($resultado){
         $sql = "UPDATE usuario SET pontuacao = '$pontos' WHERE id = '$id'";
         $banco->query($sql);
         header("location: ../../index.php");
     }else{
         header("location: ../../index.php");
     }
    }
}
$banco->close();

<?php
$host = "localhost"; //url do banco de dados
$usuario = "root"; //usuario do banco de dados
$senha = "minimundosojogoqueesuacara"; //senha do usuario do banco de dados
$bdname = "projeto"; //nome do banco de dados

//faço a coneção pelo metodo new mysqli, usando programação orientada a objetos
$banco = new mysqli($host, $usuario, $senha, $bdname);

//verifico se existe um erro, caso contrario mostrar o erro e travar o sistema com o metodo die()
if($banco->connect_errno){
    echo"<p>Encontrei um erro $banco->errno --->  {$banco->connect_error}</p>";
    die();
}

?>

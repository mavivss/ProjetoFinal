<?php
//Insiro a conexão com o banco de dados nesse arquivo
require_once("conexao.php");

//Faço a validão das informações que veio da tela de cadastro, evitando SQL INJECTION e tags HTML, transformando o sistema mais seguro
$nome = trim(addslashes(htmlspecialchars($_POST['nome'])));
$email = trim(addslashes(htmlspecialchars($_POST['email'])));
$senha = trim(addslashes(htmlspecialchars($_POST['senha'])));
//Criptografo a senha, para manter as informações do usuario segura
$senha = password_hash($senha, PASSWORD_DEFAULT);
//Coloco um valor que o usuario terá na bio quando ele se cadastrar
$bio = "";

//Faço uma consulta com o e-mail que o usuario informou
$sqlSelect = "SELECT * FROM usuario WHERE email = '$email'";
$resultSelect = $banco->query($sqlSelect);
//Valido se esse email já foi cadastrado e se as outras informações tem algum conteudo
if ($resultSelect->num_rows > 0 or empty($nome) or empty($email) or empty($senha)) {
    header("location: ../../cadastro.php");
} else {
    //Caso o email ainda nn foi cadastrado, faça a inserção dele no banco
    $sqlInsert = "INSERT INTO usuario (nome, email, senha, foto, bio, pontuacao, permissao) VALUES ('{$nome}', '{$email}','{$senha}', 'perfil.png','$bio', 0,1)";
    $result = $banco->query($sqlInsert);
}
//Logo depois, com este usuario cadastrado, faço o login dele
if ($result) {
    //Faço uma consulta com esse email
    $sqlSelect = "SELECT * FROM usuario WHERE email = '{$email}'";
    $resultSelectTwo = $banco->query($sqlSelect);
    if ($resultSelectTwo) {
        $row = $resultSelectTwo->fetch_assoc();
        //Crio um cookie com o id dele criptografado, para validar o acesso dele na pagina de logado
        $cookie = password_hash($row['id'], PASSWORD_DEFAULT);
        setcookie("hash", "$cookie", time() + 3600 * 60 * 60 * 60, "/");
        header("location: ../../index.php");
    }
} else {
    //$_SESSION['alert'] = "Informações inválidas";
    header("location: ../../cadastro.php");
}

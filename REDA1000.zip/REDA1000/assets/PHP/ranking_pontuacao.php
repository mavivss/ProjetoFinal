<?php
session_start();

require_once("conexao.php");
//Adicionando 1 ponto para o usuario a cada 10 minutos ativo no sistema, validação feita pelo JAVASCRIPT(ajax)
$id = $_SESSION['id'];
if (!empty($id)) {
    //Consultar o usuario com o id igual ao que está logado
    $sqlSelect = "SELECT * FROM usuario WHERE id = '$id'";
    $result = $banco->query($sqlSelect);
    //verificar se o numero de linhas é maior que zero
    if ($result->num_rows > 0) {
        $linhas = $result->fetch_assoc();
        $pontos = $linhas['pontuacao'];
        $pontos = $pontos + 1;
        //modificar o valor do atributo pontuação e adicionar o novo ponto
        $sql = "UPDATE usuario SET pontuacao = '$pontos' WHERE id = '$id'";
        $banco->query($sql);
    }
}

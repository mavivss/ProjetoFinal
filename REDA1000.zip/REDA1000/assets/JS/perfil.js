function postagem(url) {
    $.ajax({
        url: `assets/PHP/PERFIL/${url}.php`,
        method: 'POST',
        dataType: 'json',
        success: function (response) {
            document.getElementById("perfil-publicacao").innerHTML = `${response.conteudo}`;
        }
    });
}
postagem('meusposts');
document.querySelector('.btn-meusposts').addEventListener('click', () => {
    postagem('meusposts')
});
document.querySelector('.btn-likes').addEventListener('click', () => {
    postagem('likes')
});
document.querySelector('.btn-comentarios').addEventListener('click', () => {
    postagem('comentarios')
});
//Modificar foto do perfil
function fotoperfil() {
    $.ajax({
        name: 'fotoperfil',
        url: `assets/PHP/foto_perfil.php`,
        method: 'POST',
        dataType: 'json',
        type: "POST",
        processData: false,
        contentType: false,
        data: new FormData($('#myForm')[0]),
        cache: false,
        success: function (response) {
            document.querySelector('.msg-alert').innerHTML = `${response.mensagem}`
            document.querySelector('.alert').classList.add('alert-keyframes');

            setTimeout(() => {
                document.querySelector('.alert').classList.remove('alert-keyframes');
            }, 8000);

        }
    });
}

//Recarregar foto de perfil e mostrar ta tag IMG, informando para o usuario que ele fez upload de uma nova imagem
const reader3 = new FileReader();
document.querySelector('#foto').addEventListener('change', function () {
    var imagemperfil = document.querySelector('#foto').files[0];
    var preview = document.querySelector('.imagemperfil');
    reader3.onloadend = function () {
        preview.src = reader3.result;
    }
    if (imagemperfil) {
        reader3.readAsDataURL(imagemperfil);
        setTimeout(() => {
            fotoperfil();
        }, 500);
    } else {
        preview.src = "";
    }
})
document.querySelector('.deletar-account').addEventListener('click', () => {
    document.querySelector('.alert-deleteAccount').classList.add('alert-deleteAccount-Block')

    setTimeout(() => {
        document.querySelector('.alert-deleteAccount').classList.remove('alert-deleteAccount-Block')
    }, 300000);
});
document.querySelector('.deletar-account-close').addEventListener('click', () => {
    document.querySelector('.alert-deleteAccount').classList.remove('alert-deleteAccount-Block')
});
document.querySelector('#biografia').addEventListener('input', (e) => {
    if (e.target.value.length >= 201) {
        e.target.value = e.target.value.substr(0, 200);
    }
    document.querySelector('.tamanho-textarea').innerHTML = e.target.value.length;
});

document.querySelector('.tamanho-textarea').innerHTML = document.querySelector('#biografia').value.length;

document.querySelector('.alterarOne').addEventListener('click', () => {
    document.querySelector('.dadosOne').classList.add('dados-mostrar')
    document.querySelector('.dadosTwo').classList.remove('dados-mostrar')
});
document.querySelector('.alterarTwo').addEventListener('click', () => {
    document.querySelector('.dadosTwo').classList.add('dados-mostrar')
    document.querySelector('.dadosOne').classList.remove('dados-mostrar')
});

document.querySelector('.menuclick').addEventListener(() => {
    document.queryCommandSupported('.menuop').classList.toggle('menu');
});




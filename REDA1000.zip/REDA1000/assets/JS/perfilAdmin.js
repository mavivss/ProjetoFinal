
var conteudoUpload = document.querySelector('.foto-editor-conteudo');

const reader = new FileReader();
document.querySelector('#fotoEditor').addEventListener('change', function () {
    var imagem = document.querySelector('#fotoEditor').files[0];
    reader.onloadend = function () {
        var img = document.createElement("img");
        img.classList.add('foto-editor-postar');
        img.setAttribute("alt", "capa do material")
        img.src = reader.result;
        conteudoUpload.appendChild(img);
        conteudoUpload.classList.add("fotoBlock");
    }
    if (imagem) {
        reader.readAsDataURL(imagem);
    } else {
        img.src = reader.result;
    }
})

const reader2 = new FileReader();
document.querySelector('#pdfEditor').addEventListener('change', function () {
    var pdfUp = document.querySelector('#pdfEditor').files[0];
    reader2.onloadend = function () {
        var pdf = document.createElement("object");
        pdf.classList.add('pdf-editor-postar');
        pdf.setAttribute("type", "application/pdf");
        pdf.setAttribute("data", reader2.result);
        conteudoUpload.appendChild(pdf);
        conteudoUpload.classList.add("fotoBlock");
    }
    if (pdfUp) {
        reader2.readAsDataURL(pdfUp);
    } else {
        pdf.setAttribute("data", "");
    }
})
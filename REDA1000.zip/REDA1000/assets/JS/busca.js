
//Precorro todas as tags com tem a CLASS curtirfoto, e quando o usuario clicar em uma delas, eu chamo a função curtirpub

let curtir = document.querySelectorAll(".curtirfoto")
for (let curtiPost of curtir) {
    curtiPost.addEventListener('click', curtirPub);
}
function curtirPub(e) {
    //Pego a tag html que foi clicada com o target
    let clickcurtir = e.target
    //se o botão curtir já tem a CLASS btnCurtida, remove, caso contrario adiciona, mas o importante é mostrar para usuario que aquela publicacao ja foi curtida
    clickcurtir.classList.toggle("btnCurtida");
    //No botão, eu quero pego o valor de um atributo data-id, cujo valor é o ID da publicacao
    let idpublicacao = clickcurtir.dataset.id;
    //Faço a curtida via ajax, desta forma, o usuario não precisa atualizar a página toda hora que ele curtir uma foto, coloca a url que vai armazenar a curtida, o metodo, e coloco os vamos que serão enviado no metodo POST
    $.ajax({
        url: 'assets/PHP/curtida.php',
        method: 'POST',
        dataType: 'json',
        data: {
            idpublicacao: idpublicacao
        }
    });
}

//Mostrar todos os comentários da publicação que tem o ID "comentarioClickId"
function comentarios(comentarioClickId){
    $.ajax({
        url: 'assets/PHP/comentario_mostrar.php',
        method: 'POST',
        dataType: 'json',
        data: {
            idpublicacao: comentarioClickId,
        },
        success: function (response) {
            document.querySelector(`.comentariofoto${comentarioClickId} #comment`).innerHTML = `<div class='comentarios-redacao'>${response.conteudo}</div>`;;          
        }
    });
}

let comentario = document.querySelectorAll('.btncomentario')
for (let comentarioPost of comentario) {
    comentarioPost.addEventListener('click', comentarioPub);
}
//Quando usuario abertar o botão comentario, essa funcao vai abrir o comentario, e depois chamar a funçã comentarios, que vai mostrar todos os comentarios daquela publicação
function comentarioPub(e){
    let comentarioClickId = e.target.dataset.id;
    document.querySelector(`.comentariofoto${comentarioClickId}`).classList.toggle('comentario-mostrar');
    comentarios(comentarioClickId);
}
//Precorrer todas as publicações pra saber em qual botão o usuario clicou pra enviar um comentario, chamando a funcao "comentarioPubForm"
let comentarioform = document.querySelectorAll('.formcomentario')
for (let comentarioPostform of comentarioform) {
    comentarioPostform.addEventListener('click', comentarioPubForm);
}

function comentarioPubForm(e){
    e.preventDefault(); //Evitar com que o site leve o usuario pra outra pagina
    let texto = document.querySelector(`.coment${e.target.dataset.id}`);
    let idpublicacao = e.target.dataset.id;
    //Verifico se usuario nn clickou errado e se o texto é maior que ZERO, caso não seja, envio o comentario
    if(texto != undefined && texto.value.length > 0){
        let textoConteudo = texto.value;
        $.ajax({
            url: 'assets/PHP/comentario.php',
            method: 'POST',
            dataType: 'json',
            data: {
                idpublicacao: idpublicacao,
                texto: textoConteudo 
            },
            success: function (response) {
                if(response.status == "sucess"){
                    texto.value = ""; //Quando o usuario enviar seu comentario, quero que o campo de input fique vazio
                }
            }

        });
        setTimeout(()=>{
            comentarios(idpublicacao); //depois de 1 segundo, quero mostrar os comentarios atualizados, com o meu presente nessa lista
        },1000)
    }
}

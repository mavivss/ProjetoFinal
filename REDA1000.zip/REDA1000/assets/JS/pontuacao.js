//Adicionar 1 ponto no ranking para o usuario a cada 10 min
function rankingPontuacao() {
    $.ajax({
        url: 'assets/PHP/ranking_pontuacao.php',
        method: 'POST',
        dataType: 'json'
    });
}

setInterval(() => {
    rankingPontuacao(); 
}, 600000); //10 minutos 
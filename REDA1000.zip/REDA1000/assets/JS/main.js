//Abrir e fechar MENU
document.querySelector('.menu').addEventListener('click', () => {
    document.querySelector('.menu-item').classList.toggle('menu-item-mostrar');
});
document.querySelector('#container').addEventListener('click', () => {
    document.querySelector('.menu-item').classList.remove('menu-item-mostrar');
});
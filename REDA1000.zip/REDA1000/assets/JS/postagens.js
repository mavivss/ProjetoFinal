const reader = new FileReader();
document.querySelector('#fotoEditor').addEventListener('change', function () {
    var imagem = document.querySelector('#fotoEditor').files[0];
    var preview = document.querySelector('.foto-editor-postar');
    reader.onloadend = function () {
        preview.src = reader.result;
        document.querySelector('.foto-editor-conteudo').classList.add("fotoBlock");
    }
    if (imagem) {
        reader.readAsDataURL(imagem);
    } else {
        preview.src = "";
    }
})

let curtir = document.querySelectorAll(".curtirfoto")
for (let curtiPost of curtir) {
    curtiPost.addEventListener('click', curtirPub);
}

function curtirPub(e) {
    let clickcurtir = e.target
    clickcurtir.classList.toggle("btnCurtida");
    let idpublicacao = clickcurtir.dataset.id;
    $.ajax({
        url: 'assets/PHP/curtida.php',
        method: 'POST',
        dataType: 'json',
        data: {
            idpublicacao: idpublicacao
        }
    });
}

function comentarios(comentarioClickId) {
    $.ajax({
        url: 'assets/PHP/comentario_mostrar.php',
        method: 'POST',
        dataType: 'json',
        data: {
            idpublicacao: comentarioClickId,
        },
        success: function (response) {
            if(response.status == "sucess"){
                document.querySelector(`.comentariofoto${comentarioClickId} #comment`).innerHTML = `<div class='comentarios-redacao'>${response.conteudo}</div>`;
            }else{
                document.querySelector(`.comentariofoto${comentarioClickId} #comment`).innerHTML = `<div class='comentarios-redacao'><div class='comentarios-conteudo'><p>Desculpa! Tivemos um erro, tenta novamente mais tarde.</p></div></div>`;
            }
        }
    });
}

let comentario = document.querySelectorAll('.btncomentario')
for (let comentarioPost of comentario) {
    comentarioPost.addEventListener('click', comentarioPub);
}

function comentarioPub(e) {
    let comentarioClickId = e.target.dataset.id;
    document.querySelector(`.comentariofoto${comentarioClickId}`).classList.toggle('comentario-mostrar');
    comentarios(comentarioClickId);
}
let comentarioform = document.querySelectorAll('.formcomentario')
for (let comentarioPostform of comentarioform) {
    comentarioPostform.addEventListener('click', comentarioPubForm);
}

function comentarioPubForm(e) {
    e.preventDefault();
    let texto = document.querySelector(`.coment${e.target.dataset.id}`);
    let idpublicacao = e.target.dataset.id;
    if (texto != undefined && texto.value.length > 0) {
        let textoConteudo = texto.value;
        $.ajax({
            url: 'assets/PHP/comentario.php',
            method: 'POST',
            dataType: 'json',
            data: {
                idpublicacao: idpublicacao,
                texto: textoConteudo
            },
            success: function (response) {
                if (response.status == "sucess") {
                    texto.value = "";
                }
            }

        });
        setTimeout(() => {
            comentarios(idpublicacao);
        }, 1000)
    }
}

let deletar = document.querySelectorAll('.deletePub');
for (let deletePost of deletar) {
    deletePost.addEventListener('click', deletarPublicacao);
}
function deletarPublicacao(e){
    document.querySelector(`.deleta-${e.target.parentElement.dataset.id}`).classList.toggle('deletePub-m-flex');
}
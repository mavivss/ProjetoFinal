<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Reda1000 | Uma comunidade para estudantes</title>
    <meta charset="UTF-8">
    <meta name="title" content="Reda1000 | Uma comunidade para estudantes">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Reda1000, o lugar perfeito para melhorar em redação.">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta property="og:type" content="website">
    <meta property="og:title" content="Reda1000 | Uma comunidade para estudantes">
    <meta property="og:description"
        content="Reda1000, o lugar perfeito para melhorar em redação.">
    <meta property="og:image" content="./assets/IMG/FAVICON/android-chrome-512x512.png">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="Reda1000 | Uma comunidade para estudantes">
    <meta property="twitter:description"
        content="Reda1000, o lugar perfeito para melhorar em redação.">
    <meta property="twitter:image" content="./assets/IMG/FAVICON/android-chrome-512x512.png">
    <script src="https://kit.fontawesome.com/fbcc70bc24.js" crossorigin="anonymous"></script>
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/IMG/FAVICON/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/IMG/FAVICON/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./assets/IMG/FAVICON/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
</head>

<body>
    <header id="cabecalho">
        <div class="logo">
            <p><img src="assets/IMG/FAVICON/apple-touch-icon.png" alt="logo"> Reda1000</p>
        </div>
        <div class="busca">
            <form class="header-busca" action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="opcoes">
            <ul>
                <a class="criarconta" href="cadastro.php">
                    <li>Criar Conta</li>
                </a>
                <a class="fazerlogin" href="login.php">
                    <li>Fazer Login</li>
                </a>
            </ul>
        </div>
        <nav class="menu-item">
            <button class="fazerpostagens"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
            <form action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
            <ul>
                <a href="index.php">
                    <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Fazer Login</span></li>
                </a>
                <a href="cadastro.php">
                    <li><i class="fa fa-users" aria-hidden="true"></i><span>Fazer Cadastro</span></li>
                </a>
            </ul>
        </nav>
        <svg class="menu" width="35" height="35" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" color="#000"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
    </header>
    <section id="container">
        <div class="sidebar">
            <div class="sidebarConteudo">
                <div class="inscrever">
                    <button><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
                </div>
                <div class="diretorio">
                    <ul>
                        <a href="index.php">
                            <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                        </a>
                        <a href="login.php">
                            <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                        </a>
                        <a href="login.php">
                            <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                        </a>
                    </ul>
                </div>
                <div class="diretorioTwo">
                    <ul>
                        <a href="login.php">
                            <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
        <div class="publicacao">
            <?php include_once('./assets/PHP/mostrar_postagem_index.php') ?>
        </div>
        <div class="material">
            <h1>Material</h1>
            <div class="material-conteudo"><?php include_once("./assets/PHP/mostrar_material.php"); ?></div>
        </div>
    </section>
<script src="./assets/JS/main.js"></script>
</body>

</html>
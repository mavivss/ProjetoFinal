<?php
require_once("./assets/PHP/conexao.php");

//verificando se o ususario está logado
$logado = false;
//verificando se o cookie hash tem algum conteudo
if (!empty($_COOKIE['hash'])) {
    $sqlSelect = "SELECT * FROM usuario";
    $result = $banco->query($sqlSelect);
    while ($linhas = $result->fetch_assoc()) {
        //verificando se o valor do cookie hash é igual algum valor do banco de dados
        $condicao = password_verify($linhas['id'], $_COOKIE['hash']) ? true : false;
        if ($condicao) {
            $logado = true; 
            //caso seja, retorne true, informando que o usuario pode contiar na pagina 

            //o break serve pra parar o laço de repetição
            break;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Reda1000 | Uma comunidade para estudantes</title>
    <meta charset="UTF-8">
    <meta name="title" content="Reda1000 | Uma comunidade para estudantes">
    <meta name="description" content="Reda1000, o lugar perfeito para melhorar em redação.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/IMG/FAVICON/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/IMG/FAVICON/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./assets/IMG/FAVICON/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
</head>

<body>
    <?php if($logado == true ){ ?>
    <header id="cabecalho">
        <div class="logo">
            <p><img src="assets/IMG/FAVICON/apple-touch-icon.png" alt="logo"> Reda1000</p>
        </div>
        <div class="busca">
            <form class="header-busca" action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="opcoes">
            <ul>
                <li><?= $nome ?></li>
                <li><img src="./assets/IMG/PERFIL/<?= $foto ?>" alt="foto de perfil"></li>
            </ul>
        </div>
        <nav class="menu-item">
            <button class="fazerpostagens"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
            <form action="#" method="get">
                <input type="text" name="buscarPostagem" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
            <ul>
                <a href="home.php">
                    <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                </a>
                <a href="perfil.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                </a>
                <a href="ranking.php">
                    <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                </a>
                <a href="perfil.php?configuracoes=true">
                    <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                </a>
                <a href="assets/PHP/logout.php">
                    <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                </a>
            </ul>
        </nav>
        <svg class="menu" width="35" height="35" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" color="#000">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
        </svg>
    </header>
    <section id="container">
        <div class="sidebar">
            <div class="sidebarConteudo">
                <div class="inscrever">
                    <button><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
                </div>
                <div class="diretorio">
                    <ul>
                        <a href="index.php">
                            <li><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                        </a>
                        <a href="perfil.php">
                            <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                        </a>
                        <a href="ranking.php">
                            <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                        </a>
                    </ul>
                </div>
                <div class="diretorioTwo">
                    <ul>
                        <a href="perfil.php?configuracoes=true">
                            <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                        </a>
                        <a href="assets/PHP/logout.php">
                            <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
        <div class="publicacao">
            <?php include_once("assets/PHP/mostrar_postagem_busca.php"); ?>
        <div class="material">
            <h1>Material</h1>
            <div class="material-conteudo"><?php include_once("./assets/PHP/mostrar_material.php"); ?></div>
        </div>
    </section>
    <?php }else{ ?>
        <header id="cabecalho">
        <div class="logo">
            <p><img src="assets/IMG/FAVICON/apple-touch-icon.png" alt="logo"> Reda1000</p>
        </div>
        <div class="busca">
            <form class="header-busca" action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="opcoes">
            <ul>
                <a class="criarconta" href="cadastro.php">
                    <li>Criar Conta</li>
                </a>
                <a class="fazerlogin" href="login.php">
                    <li>Fazer Login</li>
                </a>
            </ul>
        </div>
        <nav class="menu-item">
            <button class="fazerpostagens"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
            <form action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
            <ul>
                <a href="index.php">
                    <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                </a>
                <a href="login.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Fazer Login</span></li>
                </a>
                <a href="cadastro.php">
                    <li><i class="fa fa-users" aria-hidden="true"></i><span>Fazer Cadastro</span></li>
                </a>
            </ul>
        </nav>
        <svg class="menu" width="35" height="35" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" color="#000"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
    </header>
    <section id="container">
        <div class="sidebar">
            <div class="sidebarConteudo">
                <div class="inscrever">
                    <button class="fazerpostagensTwo"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
                </div>
                <div class="diretorio">
                    <ul>
                        <a href="index.php">
                            <li><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                        </a>
                        <a href="login.php">
                            <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                        </a>
                        <a href="login.php">
                            <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                        </a>
                    </ul>
                </div>
                <div class="diretorioTwo">
                    <ul>
                        <a href="login.php">
                            <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
        <div class="publicacao">
            <?php include_once('./assets/PHP/mostrar_postagem_busca.php') ?>
        </div>
        <div class="material">
            <h1>Material</h1>
            <div class="material-conteudo"><?php include_once("./assets/PHP/mostrar_material.php"); ?></div>
        </div>
    </section>
    <?php } ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="./assets/JS/main.js"></script>
    <script src="./assets/JS/busca.js"></script>
    <script src="./assets/JS/pontuacao.js"></script>
    <script>
        document.querySelector('.fazerpostagens').addEventListener('click', () => {
            document.querySelector('.publicacao').scrollTop = 0;
        })
        document.querySelector('.fazerpostagensTwo').addEventListener('click', () => {
            document.querySelector('.publicacao').scrollTop = 0;
        })
    </script>
</body>

</html>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Reda1000 | Uma comunidade para estudantes</title>
    <meta charset="UTF-8">
    <meta name="title" content="Reda1000 | Uma comunidade para estudantes">
    <meta name="description" content="Reda1000, o lugar perfeito para melhorar em redação.">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <script src="https://kit.fontawesome.com/fbcc70bc24.js" crossorigin="anonymous"></script>
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/IMG/FAVICON/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/IMG/FAVICON/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./assets/IMG/FAVICON/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
</head>

<body>
    <header id="cabecalho">
        <div class="logo">
            <p><img src="assets/IMG/FAVICON/apple-touch-icon.png" alt="logo"> Reda1000</p>
        </div>
        <div class="busca">
            <form class="header-busca" action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="opcoes">
            <ul>
                <li><?= $nome ?></li>
                <li><img src="./assets/IMG/PERFIL/<?= $foto ?>" alt="foto de perfil"></li>
            </ul>
        </div>
        <nav class="menu-item">
            <button class="fazerpostagens"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
            <form action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
            <ul>
                <a href="home.php">
                    <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                </a>
                <a href="perfil.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                </a>
                <a href="ranking.php">
                    <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                </a>
                <a href="perfil.php?configuracoes=true">
                    <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                </a>
                <a href="assets/PHP/logout.php">
                    <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                </a>
            </ul>
        </nav>
        <svg class="menu" width="35" height="35" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" color="#000">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
        </svg>
    </header>
    <section id="container">
        <div class="sidebar">
            <div class="sidebarConteudo">
                <div class="inscrever">
                    <button class="fazerpostagensTwo"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
                </div>
                <div class="diretorio">
                    <ul>
                        <a href="index.php">
                            <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                        </a>
                        <a href="perfil.php">
                            <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                        </a>
                        <a href="ranking.php">
                            <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                        </a>
                    </ul>
                </div>
                <div class="diretorioTwo">
                    <ul>
                        <a href="perfil.php?configuracoes=true">
                            <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                        </a>
                        <a href="assets/PHP/logout.php">
                            <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                        </a>
                         </ul>
                </div>
            </div>
        </div>
        <div class="publicacao">
            <form class="editorTexto" action="assets/PHP/enviar_postagem.php" method="post" encType="multipart/form-data">
                <div class="editor">
                    <input type="text" name="titulo-pEditor" placeholder="Titulo da redação" class="titulo-editor">
                    <textarea onkeydown="textarea(event)" placeholder="Digite sua redação" name="redacao-pEditor" id="redacaoEditor"></textarea>
                    <div class="foto-editor-conteudo">
                        <img class="foto-editor-postar" src="./assets/IMG/PERFIL/perfil.png" alt="foto da publicacao">
                    </div>
                    <input type="file" name="foto-pEditor" id="fotoEditor">
                    <div class="editor-opcoes">
                        <div class="editor-btn">
                            <button>Enviar</button>
                        </div>
                        <div class="editor-btn">
                            <label for="fotoEditor" id="fotoEditorLabel">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="jss122">
                                    <path d="M20 5H4V19L13.292 9.706C13.4795 9.51853 13.7338 9.41321 13.999 9.41321C14.2642 9.41321 14.5185 9.51853 14.706 9.706L20 15.01V5ZM2 3.993C2.00183 3.73038 2.1069 3.47902 2.29251 3.29322C2.47813 3.10742 2.72938 3.00209 2.992 3H21.008C21.556 3 22 3.445 22 3.993V20.007C21.9982 20.2696 21.8931 20.521 21.7075 20.7068C21.5219 20.8926 21.2706 20.9979 21.008 21H2.992C2.72881 20.9997 2.4765 20.895 2.29049 20.7088C2.10448 20.5226 2 20.2702 2 20.007V3.993ZM8 11C7.46957 11 6.96086 10.7893 6.58579 10.4142C6.21071 10.0391 6 9.53043 6 9C6 8.46957 6.21071 7.96086 6.58579 7.58579C6.96086 7.21071 7.46957 7 8 7C8.53043 7 9.03914 7.21071 9.41421 7.58579C9.78929 7.96086 10 8.46957 10 9C10 9.53043 9.78929 10.0391 9.41421 10.4142C9.03914 10.7893 8.53043 11 8 11Z" fill="black"></path>
                                </svg>
                                <p>Foto</p>
                            </label>
                        </div>
                    </div>
                </div>
            </form>
            <?php include_once("assets/PHP/mostrar_postagem.php"); ?>
            <div class="material">
                <h1>Material</h1>
                <div class="material-conteudo"><?php include_once("./assets/PHP/mostrar_material.php"); ?></div>
            </div>
    </section>
    <?php
    if(!empty($_SESSION['alert'])){
        echo "
        <div class='alert-session'>
            <p class='msg-alert-session'>{$_SESSION['alert']}</p>
        </div>
        ";
    }
    unset($_SESSION['alert']);
    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="./assets/JS/main.js"></script>
    <script src="./assets/JS/postagens.js"></script>
    <script src="./assets/JS/pontuacao.js"></script>
    <script>
        document.querySelector('.fazerpostagens').addEventListener('click', () => {
            document.querySelector('.publicacao').scrollTop = 0;
        })
        document.querySelector('.fazerpostagensTwo').addEventListener('click', () => {
            document.querySelector('.publicacao').scrollTop = 0;
        })
    </script>
</body>

</html>
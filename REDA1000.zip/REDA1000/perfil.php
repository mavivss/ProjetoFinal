<?php
session_start();
require_once("./assets/PHP/conexao.php");
include_once("./assets/PHP/ranking_validar.php");
$nome = "";
$foto = "";
$condicao = true;

if (!empty($_COOKIE['hash'])) {
    $sqlSelect = "SELECT * FROM usuario";
    $result = $banco->query($sqlSelect);
    while ($linhas = $result->fetch_assoc()) {
        $condicao = password_verify($linhas['id'], $_COOKIE['hash']) ? true : false;
        if ($condicao) {
            $nome = $linhas['nome'];
            $foto = $linhas['foto'];
            $email = $linhas['email'];
            $bio = $linhas['bio'];
            $_SESSION['id'] = $linhas['id'];
            $_SESSION['nome'] = $linhas['nome'];
            $_SESSION['foto'] = $linhas['foto'];
            $permissao = $linhas['permissao'];
            $condicao = false;
            break;
        }
    }
}
if ($condicao) {
    header('location: index.php');
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Perfil de <?= $nome ?> | Reda1000</title>
    <meta charset="UTF-8">
    <meta name="title" content="AjudaPet - Transando o mundo animal em um lugar melhor">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Junte-se ao Pequeno Seguro, uma plataforma onde você pode interagir com outras pessoas, debater formas de combater esse crime contra as crinças. Venha! conheça já o nosso sistema.">
    <meta name="author" content="Eliane Gomes, José Antônio, Flavio Igor, Lucas Nascimento, Maria Clara">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta property="og:type" content="website">
    <meta property="og:title" content="AjudaPet - Transando o mundo animal em um lugar melhor">
    <meta property="og:description" content="Junte-se ao Pequeno Seguro, uma plataforma onde você pode denúnciar, interagir com outras pessoas, debater formas de combater esse crime contra as crinças. Venha! conheça já o nosso sistema.">
    <meta property="og:image" content="./assets/IMG/FAVICON/android-chrome-512x512.png">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="AjudaPet - Transando o mundo animal em um lugar melhor">
    <meta property="twitter:description" content="Junte-se ao Pequeno Seguro, uma plataforma onde você pode denúnciar, interagir com outras pessoas, debater formas de combater esse crime contra as crinças. Venha! conheça já o nosso sistema.">
    <meta property="twitter:image" content="./assets/IMG/FAVICON/android-chrome-512x512.png">
    <script src="https://kit.fontawesome.com/fbcc70bc24.js" crossorigin="anonymous"></script>
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/IMG/FAVICON/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/IMG/FAVICON/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./assets/IMG/FAVICON/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
</head>
<style>
    #perfil-publicacao {
        display: contents;
    }
</style>

<body>
    <header id="cabecalho">
        <div class="logo">
            <p><img src="assets/IMG/FAVICON/apple-touch-icon.png" alt="logo"> Reda1000</p>
        </div>
        <div class="busca">
            <form class="header-busca" action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="opcoes">
            <ul>
                <li><?= $nome ?></li>
                <li><img src="./assets/IMG/PERFIL/<?= $foto ?>" alt=""></li>
            </ul>
        </div>
        <nav class="menu-item">
            <button class="fazerpostagens"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
            <form action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
            <ul>
                <a href="index.php">
                    <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                </a>
                <a href="perfil.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                </a>
                <a href="ranking.php">
                    <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                </a>
                <a href="perfil.php?configuracoes=true">
                    <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                </a>
                <a href="assets/PHP/logout.php">
                    <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                </a>
            </ul>
        </nav>
        <svg class="menu" width="35" height="35" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" color="#000">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
        </svg>
    </header>
    <section id="container">
        <div class="sidebar">
            <div class="sidebarConteudo">
                <div class="inscrever">
                    <button><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
                </div>
                <div class="diretorio">
                    <ul>
                        <a href="index.php">
                            <li><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                        </a>
                        <a href="perfil.php">
                            <li class="checkdir"><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                        </a>
                        <a href="ranking.php">
                            <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                        </a>
                    </ul>
                </div>
                <div class="diretorioTwo">
                    <ul>
                        <a href="perfil.php?configuracoes=true">
                            <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                        </a>
                        <a href="assets/PHP/logout.php">
                            <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
        <div class="publicacao">
            <div class="perfil">
                <div class="perfil-conteudo">
                    <img class="foto-perfil" src="./assets/IMG/PERFIL/<?= $foto ?>" alt="">
                </div>
                <div class="perfil-texto">
                    <h2><?= $nome ?></h2>
                    <h4><?= $bio ?></h4>
                    <div class="perfil-opcoes">
                        <button class="btn-meusposts">Meus Posts</button>
                        <button class="btn-likes">Likes</button>
                        <button class="btn-comentarios">Comentarios</button>
                    </div>
                </div>
            </div>
            <?php if ($permissao == 2) { ?>
                <div class='redacao'>
                    <div class='texto'>
                        <div class='texto-redacao'>
                            <h3>Publicar material de estudo</h3>
                        </div>
                    </div>
                </div>
                <form class="editorTexto" action="assets/PHP/material.php" method="post" encType="multipart/form-data">
                    <div class="editor">
                        <input type="text" name="titulo-pEditor" placeholder="Titulo do Material" class="titulo-editor">
                        <textarea placeholder="Descrição do Material" name="redacao-pEditor" id="redacaoEditor"></textarea>
                        <div class="foto-editor-conteudo"></div>
                        <input type="file" name="foto-pEditor" id="fotoEditor">
                        <input type="file" name="pdf-pEditor" id="pdfEditor">
                        <div class="editor-opcoes">
                            <div class="editor-btn">
                                <button>Enviar</button>
                            </div>
                            <div class="editor-btn">
                                <label for="fotoEditor" id="fotoEditorLabel">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" class="jss122">
                                        <path d="M20 5H4V19L13.292 9.706C13.4795 9.51853 13.7338 9.41321 13.999 9.41321C14.2642 9.41321 14.5185 9.51853 14.706 9.706L20 15.01V5ZM2 3.993C2.00183 3.73038 2.1069 3.47902 2.29251 3.29322C2.47813 3.10742 2.72938 3.00209 2.992 3H21.008C21.556 3 22 3.445 22 3.993V20.007C21.9982 20.2696 21.8931 20.521 21.7075 20.7068C21.5219 20.8926 21.2706 20.9979 21.008 21H2.992C2.72881 20.9997 2.4765 20.895 2.29049 20.7088C2.10448 20.5226 2 20.2702 2 20.007V3.993ZM8 11C7.46957 11 6.96086 10.7893 6.58579 10.4142C6.21071 10.0391 6 9.53043 6 9C6 8.46957 6.21071 7.96086 6.58579 7.58579C6.96086 7.21071 7.46957 7 8 7C8.53043 7 9.03914 7.21071 9.41421 7.58579C9.78929 7.96086 10 8.46957 10 9C10 9.53043 9.78929 10.0391 9.41421 10.4142C9.03914 10.7893 8.53043 11 8 11Z" fill="black"></path>
                                    </svg>
                                    <p>Foto</p>
                                </label>
                            </div>
                            <div class="editor-btn">
                                <label for="pdfEditor" id="pdfEditorLabel">
                                    <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M0 0h24v24H0z" fill="none"></path>
                                        <path d="M20 2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8.5 7.5c0 .83-.67 1.5-1.5 1.5H9v2H7.5V7H10c.83 0 1.5.67 1.5 1.5v1zm5 2c0 .83-.67 1.5-1.5 1.5h-2.5V7H15c.83 0 1.5.67 1.5 1.5v3zm4-3H19v1h1.5V11H19v2h-1.5V7h3v1.5zM9 9.5h1v-1H9v1zM4 6H2v14c0 1.1.9 2 2 2h14v-2H4V6zm10 5.5h1v-3h-1v3z"></path>
                                    </svg>
                                    <p>PDF</p>
                                </label>
                            </div>
                        </div>
                    </div>
                </form>
            <?php } ?>
            <div id="perfil-publicacao"></div>
        </div>
        <div class="material">
            <h1>Material</h1>
            <div class="material-conteudo"><?php include_once("./assets/PHP/mostrar_material.php"); ?></div>
        </div>
    </section>
    <?php if (@$_GET['configuracoes'] == "true") { ?>
        <div id="configuracoes">
            <div class="configuracoes">
                <a href="perfil.php"><button class="close-configuracoes"><i class="fa fa-close" aria-hidden="true"></i></button></a>
                <div class="configuracoes-left">
                    <div class="configuracoes-perfil">
                        <form id="myForm" style="display: contents;" action="assets/PHP/foto_perfil.php" method="post">
                            <img src="./assets/IMG/PERFIL/<?= $foto ?>" class="imagemperfil" alt="foto de perfil">
                            <input style="display: none;" type="file" name="fotoperfil" id="foto">
                            <label for="foto">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path>
                                </svg>
                            </label>
                        </form>
                    </div>
                    <h2><?= $nome ?></h2>
                    <div class="configuracoes-opcoes">
                        <button class="alterarOne">Alterar Dados</button>
                        <button class="alterarTwo">Alterar Senha</button>
                        <button class="deletar-account">Deletar Conta</button>
                    </div>
                </div>
                <div class="configuracoes-right">
                    <div class="dadosOne wrapper dados-mostrar">
                        <header>Configuração</header>
                        <form action="assets/PHP/modificar_dados.php" method="post">
                            <div class="dbl-field">
                                <div class="field">
                                    <input type="text" name="name" value="<?= $nome ?>" placeholder="Digite seu nome">
                                    <i class='fas fa-user'></i>
                                </div>
                                <div class="field">
                                    <input type="text" name="email" value="<?= $email ?>" placeholder="Digite seu e-mail">
                                    <i class='fas fa-envelope'></i>
                                </div>
                            </div>
                            <div class="message">
                                <textarea placeholder="Digite sua biografia" id="biografia" name="bio"><?= $bio ?></textarea>
                                <i class="fa fa-book" aria-hidden="true"></i>
                                <p><span class="tamanho-textarea">0</span>/200</p>
                            </div>
                            <div class="button-area">
                                <button type="submit">Modificar</button>
                            </div>
                        </form>
                    </div>
                    <div class="dadosTwo wrapper">
                        <header>Alterar Senha</header>
                        <form action="assets/PHP/modificar_senha.php" method="post">
                            <div class="dbl-field">
                                <legend>Senha Atual</legend>
                                <div class="field" style="width: 100%;">
                                    <input type="text" autocomplete="off" name="senhaAtual" placeholder="Digite sua senha atual">
                                    <i class="fa fa-key" aria-hidden="true"></i>
                                </div>
                                <legend style="margin-top: 20px">Nova Senha</legend>
                                <div class="field" style="width: 100%;">
                                    <input type="text" autocomplete="off" name="senhaNova" placeholder="Digite sua nova senha">
                                    <i class="fa fa-key" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="button-area">
                                <button type="submit">Modificar</button>
                                <span></span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

    <div class="alert">
        <p class="msg-alert">Mensagem</p>
    </div>
    <div class="alert-deleteAccount">
        <h2>Deletar Conta</h2>
        <p><strong>Atenção!</strong> Depois que você deletar sua conta não tem como mais voltar atrás.</p>
        <form action="assets/PHP/deletar_conta.php" method="post">
            <button>Deletar</button>
            <p class="deletar-account-close">Cancelar</p>
        </form>
    </div>
    <?php
    if(!empty($_SESSION['alert'])){
        echo "
        <div class='alert-session'>
            <p class='msg-alert-session'>{$_SESSION['alert']}</p>
        </div>
        ";
    }
    unset($_SESSION['alert']);
    ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="./assets/JS/main.js"></script>
    <script src="./assets/JS/perfil.js"></script>
    <script src="./assets/JS/pontuacao.js"></script>
    <?php if ($permissao == 2) {
        echo "<script src='./assets/JS/perfilAdmin.js'></script>";
    } ?>
</body>

</html>
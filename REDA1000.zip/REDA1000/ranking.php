<?php
session_start();
require_once("./assets/PHP/conexao.php");
include_once("./assets/PHP/ranking_validar.php");
$nome = "";
$foto = "";
$condicao = true;

if (!empty($_COOKIE['hash'])) {
    $sqlSelect = "SELECT * FROM usuario";
    $result = $banco->query($sqlSelect);
    while ($linhas = $result->fetch_assoc()) {
        $condicao = password_verify($linhas['id'], $_COOKIE['hash']) ? true : false;
        if ($condicao) {
            $nome = $linhas['nome'];
            $foto = $linhas['foto'];
            $_SESSION['id'] = $linhas['id'];
            $condicao = false;
            break;
        }
    }
}
if ($condicao) {
    header('location: index.php');
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Reda1000 | Uma comunidade para estudantes</title>
    <meta charset="UTF-8">
    <meta name="title" content="AjudaPet - Transando o mundo animal em um lugar melhor">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description"
        content="Junte-se ao Pequeno Seguro, uma plataforma onde você pode interagir com outras pessoas, debater formas de combater esse crime contra as crinças. Venha! conheça já o nosso sistema.">
    <meta name="author" content="Eliane Gomes, José Antônio, Flavio Igor, Lucas Nascimento, Maria Clara">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta property="og:type" content="website">
    <meta property="og:title" content="AjudaPet - Transando o mundo animal em um lugar melhor">
    <meta property="og:description"
        content="Junte-se ao Pequeno Seguro, uma plataforma onde você pode denúnciar, interagir com outras pessoas, debater formas de combater esse crime contra as crinças. Venha! conheça já o nosso sistema.">
    <meta property="og:image" content="./assets/IMG/FAVICON/android-chrome-512x512.png">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:title" content="AjudaPet - Transando o mundo animal em um lugar melhor">
    <meta property="twitter:description"
        content="Junte-se ao Pequeno Seguro, uma plataforma onde você pode denúnciar, interagir com outras pessoas, debater formas de combater esse crime contra as crinças. Venha! conheça já o nosso sistema.">
    <meta property="twitter:image" content="./assets/IMG/FAVICON/android-chrome-512x512.png">
    <script src="https://kit.fontawesome.com/fbcc70bc24.js" crossorigin="anonymous"></script>
    <link rel="apple-touch-icon" sizes="180x180" href="./assets/IMG/FAVICON/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="./assets/IMG/FAVICON/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="./assets/IMG/FAVICON/favicon-16x16.png">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <link rel="stylesheet" href="./assets/CSS/style.css">
</head>

<body>
    <header id="cabecalho">
        <div class="logo">
            <p><img src="assets/IMG/FAVICON/apple-touch-icon.png" alt="logo"> Reda1000</p>
        </div>
        <div class="busca">
            <form class="header-busca" action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
        </div>
        <div class="opcoes">
            <ul>
                <li><?= $nome ?></li>
                <li><img src="./assets/IMG/PERFIL/<?= $foto ?>" alt="foto de perfil"></li>
            </ul>
        </div>
        <nav class="menu-item">
            <button class="fazerpostagens"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar
                    Postagem</span></button>
            <form action="index.php" method="get">
                <input type="text" name="query" placeholder="Pesquisar" id="buscarPostagem">
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
            </form>
            <ul>
                <a href="index.php">
                    <li class="checkdir"><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                </a>
                <a href="perfil.php">
                    <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                </a>
                <a href="ranking.php">
                    <li><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                </a>
                <a href="perfil.php?configuracoes=true">
                    <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                </a>
                <a href="assets/PHP/logout.php">
                    <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                </a>
            </ul>
        </nav>
        <svg class="menu" width="35" height="35" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
            stroke="currentColor" color="#000">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
        </svg>
    </header>
    <section id="container">
        <div class="sidebar">
            <div class="sidebarConteudo">
                <div class="inscrever">
                    <button class="fazerpostagensTwo"><i class="fas fa-pencil-alt" aria-hidden="true"></i><span>Criar Postagem</span></button>
                </div>
                <div class="diretorio">
                    <ul>
                        <a href="index.php">
                            <li><i class="fa fa-home" aria-hidden="true"></i><span>Home</span></li>
                        </a>
                        <a href="perfil.php">
                            <li><i class="fa fa-user" aria-hidden="true"></i><span>Perfil</span></li>
                        </a>
                        <a href="ranking.php">
                            <li class="checkdir"><i class="fas fa-trophy" aria-hidden="true"></i><span>Ranking</span></li>
                        </a>
                    </ul>
                </div>
                <div class="diretorioTwo">
                    <ul>
                        <a href="perfil.php?configuracoes=true">
                            <li><i class="fa fa-cog" aria-hidden="true"></i><span>Configuração</span></li>
                        </a>
                        <a href="assets/PHP/logout.php">
                            <li><i class="fa fa-sign-out" aria-hidden="true"></i><span>Sair</span></li>
                        </a>
                    </ul>
                </div>
            </div>
        </div>
        <div class="publicacao">
            <div class="ranking">
                <h1 class="ranking-titulo">Ranking Semanal</h1>
                <p class="ranking-paragrafo">Confira agora as 15 primeiras pessoas que mais interagiram na plataforma</p>
                <?php include_once("assets/PHP/mostrar_ranking.php"); ?>
            </div>
        </div>
        <div class="material">
            <h1>Material</h1>
            <div class="material-conteudo"><?php include_once("./assets/PHP/mostrar_material.php"); ?></div>
        </div>
    </section>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
    <script src="./assets/JS/main.js"></script>
    <script src="./assets/JS/pontuacao.js"></script>
</body>

</html>
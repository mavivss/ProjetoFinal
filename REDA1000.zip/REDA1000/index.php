<?php
session_start();
require_once("./assets/PHP/conexao.php");
include_once("./assets/PHP/ranking_validar.php");
$nome = "";
$foto = "";
$condicao = "";
if (!empty($_COOKIE['hash'])) {
    $sqlSelect = "SELECT * FROM usuario";
    $result = $banco->query($sqlSelect);
    while ($linhas = $result->fetch_assoc()) {
        $condicao = password_verify($linhas['id'], $_COOKIE['hash']) ? true : false;
        if ($condicao) {
            $nome = $linhas['nome'];
            $foto = $linhas['foto'];
            $_SESSION['id'] = $linhas['id'];
            break;
        }
    }
}
if ($condicao) {
    if(!empty($_GET['query'])){
        include_once('HOME/busca.php');
    }else{
        include_once('HOME/home.php');
    }
} else {
    if(!empty($_GET['query'])){
        include_once('HOME/busca.php');
    }else{
        include_once('HOME/inicial.php');
    }
}


